
package supermercado;

public class Caixa {
    
    public void imprimir_recibo(){
        System.out.println("sua compra");
    }
    public void apresentar_preço(){
        System.out.println("total da sua comora:");
    }
}
