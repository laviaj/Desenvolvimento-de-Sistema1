
package supermercado;

public class Cliente {
     
    public void Realiza_pagamento(){
        System.out.println("pagamento por:");
    }
    public void Realiza_compra(){
        System.out.println("minha compra:");
    }
}
